import java.io.*;
import java.net.*;
import java.security.*;
import javax.crypto.Cipher;

public class Client {
    public static void main(String[] args) throws Exception {
        PublicKey publicKey = KeyUtil.loadPublicKey("public.key");

        String message = "Hello from Client!";
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encrypted = cipher.doFinal(message.getBytes());

        Socket socket = new Socket("localhost", 9999);
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeInt(encrypted.length);
        dos.write(encrypted);
        dos.flush();
        socket.close();
    }
}