import java.io.*;
import java.net.*;
import java.security.*;
import javax.crypto.Cipher;

public class Server {
    public static void main(String[] args) throws Exception {
        if (!new File("public.key").exists() || !new File("private.key").exists()) {
            System.out.println("Generating keys...");
            KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
            gen.initialize(2048);
            KeyPair pair = gen.generateKeyPair();
            KeyUtil.saveKey(pair.getPublic(), "public.key");
            KeyUtil.saveKey(pair.getPrivate(), "private.key");
        }

        PrivateKey privateKey = KeyUtil.loadPrivateKey("private.key");

        ServerSocket serverSocket = new ServerSocket(9999);
        System.out.println("Server started. Waiting for client...");

        Socket socket = serverSocket.accept();
        System.out.println("Client connected!");

        DataInputStream dis = new DataInputStream(socket.getInputStream());
        int length = dis.readInt();
        byte[] encryptedData = new byte[length];
        dis.readFully(encryptedData);

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] decrypted = cipher.doFinal(encryptedData);

        System.out.println("Decrypted message: " + new String(decrypted));
        socket.close();
        serverSocket.close();
    }
}