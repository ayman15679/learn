import java.io.*;
import java.security.*;
import java.security.spec.*;

public class KeyUtil {
    public static void saveKey(Key key, String fileName) throws IOException {
        FileOutputStream fos = new FileOutputStream(fileName);
        fos.write(key.getEncoded());
        fos.close();
    }

    public static byte[] loadKeyBytes(String fileName) throws IOException {
        File file = new File(fileName);
        byte[] bytes = new byte[(int) file.length()];
        FileInputStream fis = new FileInputStream(file);
        fis.read(bytes);
        fis.close();
        return bytes;
    }

    public static PublicKey loadPublicKey(String fileName) throws Exception {
        byte[] bytes = loadKeyBytes(fileName);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(bytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(spec);
    }

    public static PrivateKey loadPrivateKey(String fileName) throws Exception {
        byte[] bytes = loadKeyBytes(fileName);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(bytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePrivate(spec);
    }
}